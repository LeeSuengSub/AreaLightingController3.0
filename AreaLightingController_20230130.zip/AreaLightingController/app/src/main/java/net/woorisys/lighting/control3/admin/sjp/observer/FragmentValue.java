package net.woorisys.lighting.control3.admin.sjp.observer;

public enum FragmentValue {
    DimmingSetting,GroupSetting,ScannerSetting,GatewaySetting,Interrupt,Maintenance
}
