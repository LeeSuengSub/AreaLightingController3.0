package net.woorisys.lighting.control3.admin.domain;

import java.io.Serializable;

public class Domain implements Serializable {
}
