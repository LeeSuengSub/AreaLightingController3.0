package net.woorisys.lighting.control3.admin.sjp.server;

public enum ResultType {
    Login
}
