package net.woorisys.lighting.control3.admin.sjp.observer;

import lombok.Getter;
import lombok.Setter;

public class ResultValue {

    @Getter
    @Setter
    private boolean Result;

    @Getter
    @Setter
    private String Message;
}
