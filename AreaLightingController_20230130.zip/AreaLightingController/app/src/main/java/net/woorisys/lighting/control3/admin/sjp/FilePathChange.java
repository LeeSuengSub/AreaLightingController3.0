package net.woorisys.lighting.control3.admin.sjp;

public interface FilePathChange {
    void FileChange(String FilePath);
}
