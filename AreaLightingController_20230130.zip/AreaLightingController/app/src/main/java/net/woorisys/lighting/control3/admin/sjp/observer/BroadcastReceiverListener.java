package net.woorisys.lighting.control3.admin.sjp.observer;

public interface BroadcastReceiverListener {
    public void Result(FragmentValue fragmentValue,boolean Result,String Message);
}
