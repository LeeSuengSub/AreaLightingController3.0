package net.woorisys.lighting.control3.admin.sjp.server;

public interface ServerRequestResult {

    public boolean Result(ResultType resultType,boolean result,String reason);
}
